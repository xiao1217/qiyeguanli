self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1deadeb8bbf6250ebf5223df72d56181",
    "url": "./index.html"
  },
  {
    "revision": "71de086bb84da5c7fdfa",
    "url": "./static/css/2.57750c55.chunk.css"
  },
  {
    "revision": "ce016c7e7b42dc719c14",
    "url": "./static/css/main.f060c5b7.chunk.css"
  },
  {
    "revision": "71de086bb84da5c7fdfa",
    "url": "./static/js/2.bb61f143.chunk.js"
  },
  {
    "revision": "0766bc7b2119101ed992f12401f0f2a9",
    "url": "./static/js/2.bb61f143.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ce016c7e7b42dc719c14",
    "url": "./static/js/main.914b65fa.chunk.js"
  },
  {
    "revision": "3f4614bca1833d22bec7",
    "url": "./static/js/runtime-main.d4e1c95b.js"
  },
  {
    "revision": "afc3c5ef6d61c601278195c6cf8ded9c",
    "url": "./static/media/11.afc3c5ef.mp3"
  },
  {
    "revision": "ba5f8f6b7a8ddc69de31395e1281315d",
    "url": "./static/media/add.ba5f8f6b.png"
  },
  {
    "revision": "43091799ea5c952f07cb329210f579c8",
    "url": "./static/media/bindbg.43091799.png"
  },
  {
    "revision": "36de84837a65b950d9ea200d77d1de3d",
    "url": "./static/media/default.36de8483.png"
  },
  {
    "revision": "1b98c05dec97e451bd8515ea27842b6f",
    "url": "./static/media/loginbg.1b98c05d.png"
  },
  {
    "revision": "84d82013971b012a931e91ab6907ec0e",
    "url": "./static/media/voice.84d82013.gif"
  },
  {
    "revision": "feb3a39ae1c96344a053f42e7d339d68",
    "url": "./static/media/voice.feb3a39a.jpg"
  }
]);