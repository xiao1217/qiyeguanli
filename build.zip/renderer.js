global.electron=require("electron");
global.net=require("net");
global.path=require("path");
global.fs=require("fs");
global.sqlite3=require("sqlite3");
// global.knex=require('knex')({
//     client: 'mysql',
//     connection: {
//       host : '127.0.0.1',
//       user : 'root',
//       password : 'root',
//       database : 'test'
//     }
//   });

// global.knex=require('knex')({
//     client: 'sqlite3',
//     connection: {
//         filename: "./ceshi.db"
//     }
// });